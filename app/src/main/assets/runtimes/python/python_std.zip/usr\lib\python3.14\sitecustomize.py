﻿import os, sys, json, importlib.machinery, importlib.util
_root = os.environ.get('LARV_RUNTIME_ROOT')
if _root:
    try:
        with open(os.path.join(_root, 'ext_manifest.json'), encoding='utf-8') as f:
            mapping = json.load(f)
    except Exception:
        mapping = {}
    nat = os.environ.get('LARV_NATIVE_DIR', '')
    loader = importlib.machinery.ExtensionFileLoader
    for name, fname in mapping.items():
        p = os.path.join(nat, fname)
        try:
            l = loader(name, p)
            spec = importlib.util.spec_from_loader(name, l, origin=p)
            m = importlib.util.module_from_spec(spec)
            l.exec_module(m)
            sys.modules[name] = m
        except Exception as e:
            sys.stderr.write('[larv] ext %s: %s\n' % (name, e))
